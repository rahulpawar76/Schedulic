﻿export enum Role {
    Admin = 'admin',
    Manager = 'manager',
    Employee = 'employee',
}