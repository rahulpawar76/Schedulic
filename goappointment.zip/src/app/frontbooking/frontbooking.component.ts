import { Component, OnInit,ElementRef, ViewChild } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '@environments/environment';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-frontbooking',
  templateUrl: './frontbooking.component.html',
  styleUrls: ['./frontbooking.component.scss']
})
export class FrontbookingComponent implements OnInit {
  formExistingUser : FormGroup;
  formNewUser: FormGroup
  model: NgbDateStruct;
  date: {year: number, month: number};
  displayMonths = 1;
  navigation = 'arrows';
  @ViewChild("myDiv",{static: false}) divView: ElementRef;
  
  // checkpostalcode = true;
  catselection = true;
  subcatselection = false;
  serviceselection = false;
  dateselection = false;
  personalinfo = false;
  appointmentinfo = false;
  couponcode = false;
  paymentmethod= false;
  allUnitsBack = "";
  totalAmt ="";
  selectedItem = "";
  presentToast ="";
  addoncount = false;
  addonaddtocart = true;
  existinguser = true;
  newuser = false;
  creditcardform = false;
  checked = false;
  minVal=1;
  catdata :[];
  subcatdata :[];
  servicesdata:any= [];
  selectedsubcategory = "";
  selectedcategory = "";
  booking = {
    postalcode: ""
  };
  serviceCount:any= [];
  //postalcode :any;
  coupon = {
    couponcode_val: ""
  };
  existing_mail: any;
  timeslotview: boolean = true;
  newcustomer: boolean = false;
  validpostalcode : string = 'default';
  closecoupon: string = "default";

  selecteddate: any;

  appo_address_info = {
    appo_address:"",
    appo_state:"",
    appo_city:"",
    appo_zipcode:""
  }
  errorMessage:any;

  emailFormat = "/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/"
  onlynumeric = /^-?(0|[1-9]\d*)?$/

  constructor(
    private _formBuilder: FormBuilder,
    private http: HttpClient,
    private calendar: NgbCalendar
    
  ) { }

  ngOnInit() {
    this.formExistingUser = this._formBuilder.group({
      existing_mail: ['',[Validators.required,Validators.email]],
      existing_password: ['',Validators.required],
    })
    let emailPattern=/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/
    this.formNewUser = this._formBuilder.group({
      newUserEmail: ['',[Validators.required,Validators.email,Validators.pattern(emailPattern)]],
      newUserPassword: ['',[Validators.required,Validators.minLength(8)]],
      newUserFullname: ['',Validators.required],
      newUserPhone: ['',[Validators.required,Validators.minLength(10),Validators.maxLength(12),Validators.pattern(this.onlynumeric)]],
      newUserAddress: ['',Validators.required],
      newUserState: ['',Validators.required],
      newUserCity: ['',Validators.required],
      newUserZipcode: ['',[Validators.required,Validators.pattern(this.onlynumeric)]],
      newUserSplReq: ['']
    })
    this.fngetcategories();
    setTimeout(() => {
      this.selectToday();
    }, 1000);
    this.serviceCount.length=0
    
  }
  selectToday() {
    this.model = this.calendar.getToday();
  }
  
  isDisabled(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);

    //if you want to disable week
    // return d.getDay() == 5

    //if you want to disable particular day for every month
    // return date.day==13

    //if you want to disable particular month
    // return date.month - 1 ==0

    //if you want to disable particular day for particular month
    //return date.month - 1 ==0 && date.day==13
  }
  
  private handleError(error: HttpErrorResponse) {
    return throwError('Error! something went wrong.');
    //return error.error ? error.error : error.statusText;
  }

  private createErrorMessage(error: HttpErrorResponse){
    this.errorMessage = error.error ? error.error : error.statusText;
  }
  // postal code
  fnchangepostalcode(event){
    this.validpostalcode = 'default';
    this.booking.postalcode = "";
  }
  fncheckpostalcode(event){
    var postalcode_val =  this.booking.postalcode;
    if(postalcode_val.length == 6){
      this.fncheckavailpostal();
    }
    else if(postalcode_val.length == 0){
      this.validpostalcode = 'default';
    }
    else{
      this.validpostalcode = 'invalid';
    }
  }
  fncheckavailpostal(){
    let requestObject = {
      "business_id" : 2,
      "postal_code" : this.booking.postalcode,
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/Postal_Code_check`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      if(response.statuscode == '200'){
          this.validpostalcode = 'valid';
      }
      },
      (err) =>{
      this.validpostalcode = 'invalid';
        console.log(err)
      })
  }

  // Category
  fncategory(event,id){
    this.catselection = false;
    this.subcatselection = true;
    this.selectedcategory = id;
    this.fngetsubcategory();
  }

  fngetcategories(){
    let requestObject = {
      "business_id":2,
      "status":"E"
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'mode': 'no-cors'
    });

    this.http.post(`${environment.apiUrl}/get_all_category`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      this.catdata = response.response;
      },
      (err) =>{
        console.log(err)
      })
  }

  // Sub Category
  fnsubcategory(event,id){
    this.subcatselection = false;
    this.serviceselection = true;
    this.selectedsubcategory = id;
    this.fngetallservices();
   }
   
  // get Sub Category function
  fngetsubcategory(){
    let requestObject = {
      "category_id":this.selectedcategory,
      "sub_category_status":"E"
    };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/get_sub_category`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      this.subcatdata = response.response;
      },
      (err) =>{
        console.log(err)
      })
  }

  // services
  fnserviceselection(event){
    this.serviceselection = false;
    this.dateselection = true;
   }
   fngetallservices(){
    let requestObject = {
      "sub_category_id":this.selectedsubcategory,
      "status":"E"
    };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/get_services`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      this.servicesdata = response.response;
      console.log(JSON.stringify(this.serviceCount));
      for(let i=0; i<this.servicesdata.length;i++){
        
        this.servicesdata[i].count=0;
        console.log(JSON.stringify(this.serviceCount));
        this.serviceCount[this.servicesdata[i].id]=this.servicesdata[i];
      }
      alert(JSON.stringify(this.serviceCount));
    },
      (err) =>{
        console.log(err)
      })
   }

  // date time 
  fndatetimeselection(event){
    this.dateselection = false;
    this.personalinfo = true;
  }
  onDateSelect(event){
    this.selecteddate = event.year+'-'+event.month+'-'+event.day;
    this.fncheckdate();
  }
  fncheckdate(){
    let requestObject = {
      "business_id":2,
      "date":this.selecteddate,
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/Booking_date_check`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      if(response.statuscode == '200'){
          this.timeslotview = true;
      }
      else{
        this.timeslotview = false;
      }
      },
      (err) =>{
        this.timeslotview = false;
        console.log(err)
      })
  }

  // coupon code
  fncouponcode(event){
    this.couponcode = false;
    this.paymentmethod =true;
  }
  fncheckcouponcodebtn(){
    alert(this.closecoupon);
    alert(this.coupon.couponcode_val);
    this.fncheckavailcoupon();
  }
  fnremovecoupon(event){
    this.closecoupon = 'default';
    this.coupon.couponcode_val ="";
  }
  fncheckavailcoupon(){
    let requestObject = {
      "business_id" : 2,
      "coupon_code" : this.coupon.couponcode_val,
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/check_discount_coupon`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      if(response.statuscode == '200'){
        this.closecoupon = 'valid';
      }
      else{
        this.closecoupon = 'invalid';
      }
      },
      (err) =>{
        this.closecoupon = 'invalid';
        console.log(err)
      })
  }

  // personal info
  
  fnpersonalinfo(){
    if(this.formNewUser.invalid){
      this.formNewUser.get('newUserEmail').markAsTouched();
      this.formNewUser.get('newUserPassword').markAsTouched();
      this.formNewUser.get('newUserFullname').markAsTouched();
      this.formNewUser.get('newUserPhone').markAsTouched();
      this.formNewUser.get('newUserAddress').markAsTouched();
      this.formNewUser.get('newUserState').markAsTouched();
      this.formNewUser.get('newUserCity').markAsTouched();
      this.formNewUser.get('newUserZipcode').markAsTouched();
      return false;
    }
    this.fncheckexistingemail();
   }
   
   fnloginexisinguser(){
     if(!this.formExistingUser.valid){
      this.formExistingUser.get('existing_mail').markAsTouched();
      this.formExistingUser.get('existing_password').markAsTouched();
      return false;
     }
     alert(this.formExistingUser.get('existing_mail').value);
    this.fncheckexistingemaillogin();
   }

   fncheckexistingemaillogin(){
     let requestObject = {
      "username" : this.formExistingUser.get('existing_mail').value,
      "password" : this.formExistingUser.get('existing_password').value
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/login`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)).subscribe((response:any) => {
        console.log(this.handleError)
      },
      (err) =>{ 
        this.newcustomer = false;
        this.errorMessage = this.handleError;
      })
    }
  fncheckexistingemail(){
    this.personalinfo = false;
    this.appointmentinfo = true;

    // this.http.post(`${environment.apiUrl}/verify_customer`,requestObject,{headers:headers} ).pipe(
    //   map((res) => {
    //     return res;
    //   }),
    //   catchError(this.handleError)
    // ).subscribe((response:any) => {
    //   if(response.statuscode == '200'){
    //     this.newcustomer = true;
    //     if(this.newcustomer == true){ 
    //       this.personalinfo = false;
    //       this.appointmentinfo = true;
    //     }
    //   }
    //   else if(response.statuscode == '202'){
    //     this.newcustomer = false;
    //   }
    // },
    // (err) =>{
    //   this.newcustomer = false;
    //   console.log(err)
    // })
  }
  
  fnsameasabove(event){
    if(event.checked == true){
      this.appo_address_info.appo_address = this.formNewUser.get('newUserAddress').value;
      this.appo_address_info.appo_state = this.formNewUser.get('newUserState').value;
      this.appo_address_info.appo_city = this.formNewUser.get('newUserCity').value;
      this.appo_address_info.appo_zipcode = this.formNewUser.get('newUserZipcode').value;
    }else{
      this.appo_address_info.appo_address = "";
      this.appo_address_info.appo_state = "";
      this.appo_address_info.appo_city = "";
      this.appo_address_info.appo_zipcode = "";
    }
  } 
  
  fnappointmentinfo(event){
    this.appointmentinfo = false;
    this.couponcode = true;
   }

   fnbacktosubservice(event){
    this.dateselection = false;
    this.serviceselection = true;
   }


   fnbackfromsubservice(){
     this.serviceselection =false;
     this.subcatselection = true;
   }

   fnbackfromservice(){
    this.subcatselection = false;
    this.catselection = true;
   }

  fnshowcounter(event,service_id){
    this.serviceCount[service_id].count=1;
    console.log(JSON.stringify(this.serviceCount));
  }
  remove(event,service_id){
    if(this.serviceCount[service_id].count >= 1){
      this.serviceCount[service_id].count=this.serviceCount[service_id].count-1
      console.log(JSON.stringify(this.serviceCount));
    }
  }
  add(event,service_id){
    
    if(this.serviceCount[service_id].count <= 10)
    this.serviceCount[service_id].count=this.serviceCount[service_id].count+1
    console.log(JSON.stringify(this.serviceCount));
  } 

  fnUserType(event,usertype){
    if(usertype == "existing"){
      this.existinguser = true;
      this.newuser = false;
    }else{
      this.newuser = true;
      this.existinguser = false;
    }
    
  }

  fncreditcard(event){
    this.creditcardform =true;
  }

  fncashpayment(event){
    this.creditcardform =false;
  }

}

