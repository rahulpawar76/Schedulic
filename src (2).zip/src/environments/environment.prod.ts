export const environment = {
    production: true,

    // Live Demo
    apiUrl:         'http://goappointment.bi-team.in/goappointment_api/api',
    authApiUrl:     'http://goappointment.bi-team.in/goappointment_api/api',
    urlForLink :    'http://goappointment.bi-team.in',
    tempApiUrl:     'https://aeci-demo.she-excellence.co.za/api/risk-api'

};
