﻿export enum Role {
    Admin = 'A',
    Staff = 'SM',
    Customer = 'C',
}