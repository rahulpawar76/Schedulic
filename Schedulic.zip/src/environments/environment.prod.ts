export const environment = {
    production: true,

    // Live Demo
    googleMapAPIKey: 'AIzaSyA8RwRCpG7ajbR-pl0D58oUGzi83c6RCYk',
    apiUrl:         'https://api.schedulic.com/api',
    authApiUrl:     'https://api.schedulic.com/api',
    urlForLink :    'https://app.schedulic.com',
    tempApiUrl:     'https://api.schedulic.com/api'

};
