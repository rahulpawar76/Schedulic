import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormBuilder } from '@angular/forms';
import { environment } from '@environments/environment';
import { map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Component({
  selector: 'app-frontbooking',
  templateUrl: './frontbooking.component.html',
  styleUrls: ['./frontbooking.component.scss']
})
export class FrontbookingComponent implements OnInit {
  frontbooking : FormGroup;
  
  // checkpostalcode = true;
  subcatselection = true;
  serviceselection = false;
  subserviceselection = false;
  dateselection = false;
  personalinfo = false;
  appointmentinfo = false;
  couponcode = false;
  paymentmethod= false;
  allUnitsBack = "";
  totalAmt ="";
  selectedItem = "";
  presentToast ="";
  addoncount = false;
  addonaddtocart = true;
  existinguser = true;
  newuser = false;
  creditcardform = false;
  checked = false;
  minVal=1;
  subcatdata :[];
  servicedata :[];
  selectedsubcateory = "";
  selectedservice = "";
  postalcode :any;
  couponcode_val: any;
  validpostalcode : boolean = false;
  constructor(
    private _formBuilder: FormBuilder,
    private http: HttpClient,
    
  ) { }

  ngOnInit() {
    this.frontbooking = this._formBuilder.group({
      paymentgateway: [''],
      sub_category: [''],
    })
    this.fngetsubcategories();
    
  }
  private handleError(error: HttpErrorResponse) {
    /*console.log(error);*/
    return throwError('Error! something went wrong.');
  }
  fncheckpostalcode(event){
    this.fncheckavailpostal();
    alert(this.postalcode);

  }
  fncheckavailpostal(){
    let requestObject = {
      "business_id" : 2,
      "postal_code" : this.postalcode,
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/Postal_Code_check`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
        this.validpostalcode = true;
      },
      (err) =>{
        console.log(err)
      })
  }

  fngetsubcategories(){
    let requestObject = {
      "category_id" : 2
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/get_sub_category`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      this.subcatdata = response.response;
      },
      (err) =>{
        console.log(err)
      })
  }
  fncheckcouponcodebtn(){
    this.fncheckavailcoupon();
    alert(this.couponcode_val);
  }
  fncheckavailcoupon(){
    let requestObject = {
      "coupon_code" : this.couponcode_val,
      };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/Postal_Code_check`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
        alert("Coupon Code Is true");
      },
      (err) =>{
        console.log(err),
        alert("Coupon Code Is Not true");
      })
  }
  fncheck(event){
    //alert(JSON.stringify(event));
    //alert(event.checked);
  }
  
  fnsubcategory(event,id){
    // alert(event.checked);
    this.subcatselection = false;
    this.serviceselection = true;
    this.selectedsubcateory = id;
    this.fngetservices();
  }
  
  fnserviceselection(event,id){
    this.serviceselection = false;
    this.subserviceselection = true;
    this.selectedservice = id;
   }
  
   fnsubserviceselection(event){
    this.subserviceselection = false;
    this.dateselection = true;
   }

   fndatetimeselection(event){
    this.dateselection = false;
    this.personalinfo = true;
   }

   fnbacktosubservice(event){
    this.dateselection = false;
    this.subserviceselection = true;
   }

   fnpersonalinfo(event){
    this.personalinfo = false;
    this.appointmentinfo = true;
   }

   fnappointmentinfo(event){
    this.appointmentinfo = false;
    this.couponcode = true;
   }

   fncouponcode(event){
     this.couponcode = false;
     this.paymentmethod =true;
   }

   fnbackfromsubservice(){
     this.subserviceselection =false;
     this.serviceselection = true;
   }

   fnbackfromservice(){
    this.serviceselection = false;
    this.subcatselection = true;
   }

  fnshowcounter(event){
   this.addoncount = true;
   this.addonaddtocart = false;
   this.minVal = 1;
  }
  remove() {
    if(this.minVal >= 1){
      this.minVal--;
    }
    if(this.minVal == 0){
      this.addoncount = false;
       this.addonaddtocart = true;
    }
  }
  add() {
    if(this.minVal <= 10)
     this.minVal++;
  } 

  fnexistinguser(event){
    this.existinguser = true;
    this.newuser = false;
  }
  
  fnnewuser(event){
    this.newuser = true;
    this.existinguser = false;
  }

  fncreditcard(event){
    this.creditcardform =true;
  }

  fncashpayment(event){
    this.creditcardform =false;
  }

  // get service function
  fngetservices(){
    let requestObject = {
      "sub_category_id" : this.selectedsubcateory
    };
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    this.http.post(`${environment.apiUrl}/get_services`,requestObject,{headers:headers} ).pipe(
      map((res) => {
        return res;
      }),
      catchError(this.handleError)
    ).subscribe((response:any) => {
      this.servicedata = response.response;
      },
      (err) =>{
        console.log(err)
      })
  }

}

