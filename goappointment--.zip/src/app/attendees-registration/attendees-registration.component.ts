import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QuestionService} from '@app/_services';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Router, RouterOutlet ,ActivatedRoute} from '@angular/router';
import decode from 'jwt-decode';

@Component({
  selector: 'app-attendees-registration',
  templateUrl: './attendees-registration.component.html',
  styleUrls: ['./attendees-registration.component.scss']
})
export class AttendeesRegistrationComponent implements OnInit {

  firstFormGroup: FormGroup;
	jsonUser;
	accessToken;
  userId;
	session_id;
	statusExpiry;

  	constructor(private _formBuilder: FormBuilder,
  		private questionService: QuestionService,
  		private _snackBar: MatSnackBar,
  		public router: Router,
  		private route: ActivatedRoute) { 
  		  	}

	 ngOnInit() {
	 	this.accessToken = this.route.snapshot.paramMap.get("accessToken")
	 	const decoded = decode(this.accessToken);
    alert(JSON.stringify(decoded));
    this.userId = decoded.id;
	 	this.session_id = decoded.session_id;
	 	this.isExpiryOrNot();
	  	this.firstFormGroup = this._formBuilder.group({
	      email: [decoded.email,[Validators.email,Validators.required]],
	      firstname: [''],
	      lastname: [''],
	      group: [''],
	      OME : [''],
	      department:[''],
	      password : ['',Validators.required]
	    });
	}
	 userRegistration(event: Event) {
	 	if (this.firstFormGroup.invalid) {
            return;
        }
	    this.jsonUser = {
	      "email": this.firstFormGroup.get('email').value,
	      "firstname": this.firstFormGroup.get('firstname').value,
	      "lastname": this.firstFormGroup.get('lastname').value,
/*	      "group": this.firstFormGroup.get('group').value,
	      "OME" : this.firstFormGroup.get('OME').value,
	      "department" : this.firstFormGroup.get('department').value,*/
	      "password" : this.firstFormGroup.get('password').value,
        "role" : "employee",
	      "session_id" : this.session_id
		}
		this.saveUser();
 	}
 	saveUser() {
    this.questionService.SaveAttendees(this.jsonUser)
      .subscribe(
        (res) => {
          if(res.data){
          	//this.success = 'Created successfully';
    		    this._snackBar.open("Created successfully", "X", {
    		      duration: 2000,
    		      verticalPosition: 'top',
    		      panelClass : ['green-snackbar']
    		    });
    		    this.updateLinkExpiry();
    		    this.router.navigate(['/login']);
          }else{
          	this._snackBar.open(res.response, "X", {
		      duration: 2000,
		      verticalPosition: 'top',
		      panelClass: ['red-snackbar']
		    });
          }
          
        },
        (err) =>{
        	console.log(err)
        } 
      );
  }
  updateLinkExpiry(){
  	this.questionService.statusUpdate({id : this.userId})
      .subscribe(
        (res) => {
    	if(res.data){
    	}else{
    	}

    });
  }
  isExpiryOrNot(){
  	this.questionService.isExpiryOrNot({id : this.userId})
      .subscribe(
        (res) => {
        	if(res.data[0] == 1){
        		this.statusExpiry = true;
        	}else{
        		this.statusExpiry = false;
        	}
    });
    
  }

}
